<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);
 
// set user property values
$user->username = $_POST['username'];
$user->password = base64_encode($_POST['password']);
$user->created = date('Y-m-d H:i:s');
 
// create the user
if($user->signup()){
//redirect to login.
           //header("location:index.html"); 
 //or error message.
         Echo "You have signed up successfully";    
        }
        else
        {
            echo "username or password incorrect";
        }
?>
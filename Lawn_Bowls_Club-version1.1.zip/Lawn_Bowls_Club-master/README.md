# Lawn Bowl Scoreboard project

The aim of the project is to develop a digital score board for players and score keepers of Lawn Bowl Gaming Club for users to be able to input and display the scores, track the record with ease. The client should ensure that every player will have to register and login before playing the game. After login, every player gets an individual score card where the scores are manually entered. Each team score and rinks are summed up and displayed on a big digital screen. The main priority of our project is to provide accuracy of the scores overcoming the drawbacks of the existing system.

Keywords: Lawn Bowl, score board, players, web development, track, game.

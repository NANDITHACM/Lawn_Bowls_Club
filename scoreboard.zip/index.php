<?php
  session_start();

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Dashboard</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
<link rel="stylesheet" href="./assets/css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


</head>
<body>


<div class="login-wrap">
<div class="login-html">
  <div class="header">
  <h2>Dasboard</h2>
</div>
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php
            echo $_SESSION['success'];
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
      <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
      <p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
    <div>  
<article class="panel-group bs-accordion" id="accordion" role="tablist" aria-multiselectable="true">
      <section class="panel-lb">
        <div class="panel-heading" role="tab" id="headingOne">
          <h4 class="panel-title">
            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              New Game
              <span class="glyphicon glyphicon-chevron-down pull-right" aria-hidden="true"></span>
            </a>
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
          <div class="panel-body">
            <ul>
              <li><a href="./user/singles.php" aria-describedby="link01-01">Singles</a></li>
              <li><a href="./user/pairs.php" aria-describedby="link01-02">Pairs</a></li>
              <li><a href="triples.php" aria-describedby="link01-03">Triples</a></li>
              <li><a href="four-players.php" aria-describedby="link01-03">Four-players</a></li>
            </ul>
          </div>
        </div>
      </section>
      <section class="panel-lb">
        <div class="panel-heading" role="tab" id="headingTwo">
          <h4 class="panel-title">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
              My Details
              <span class="glyphicon glyphicon-chevron-down pull-right" aria-hidden="true"></span>
            </a>
          </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
          <div class="panel-body">
            <ul>
              <li><a href="#" id="link02-01">Account</a></li>
              <li><a href="#" id="link02-02">Games</a></li>
              <li><a href="#" id="link02-03">Scores</a></li>
            </ul>
          </div>
        </div>
      </section>
      <section class="panel-lb">
        <div class="panel-heading" role="tab" id="headingThree">
          <h4 class="panel-title">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
              My Scores
              <span class="glyphicon glyphicon-chevron-down pull-right" aria-hidden="true"></span>
            </a>
          </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
          <div class="panel-body">
            <ul>
              <li><a href="#" id="link03-01">Tournaments</a></li>
              <li><a href="#" id="link03-02">Scoreboard</a></li>
              <li><a href="#" id="link03-03">Statistics</a></li>
            </ul>
          </div>
        </div>
      </section>
      <section class="panel-lb">
        <div class="panel-heading" role="tab" id="headingThree">
          <h4 class="panel-title">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseThree">
              Settings
              <span class="glyphicon glyphicon-chevron-down pull-right" aria-hidden="true"></span>
            </a>
          </h4>
        </div>
        <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
          <div class="panel-body">
            <ul>
              <li><a href="#" id="link03-01">Font size</a></li>
              <li><a href="#" id="link03-02">Colours</a></li>
              <li><a href="#" id="link03-03">Scoreboard</a></li>
            </ul>
          </div>
        </div>
      </section>
    </article>
  </div>
</div>
  </div>
</div>

</body>
</html>

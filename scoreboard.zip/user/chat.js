var bottom = true;

jQuery(document).ready(function() {
	
	$("#text").focus();
	
	listChat();
	setInterval(function() {
		listChat();
	}, 500);
	
	listOnline();
	setInterval(function() {
		listOnline();
	}, 5000);
	
    // Sum up score values 
    
     $('#pts').keyup(function() {
        $('.pts[name="2"]').val($(this).val());
        $('#text').val($(this).val());
        $("#send").submit();
    });
    $('#pts3').keyup(function() {
        $('.pts[name="4"]').val($(this).val());
    });
      
     
    $('.pts').keyup(function () {
     
        
        var thisValue = $(this).attr('name');
        var priThird = parseFloat(thisValue) - 3;
        var nextValue = parseFloat(thisValue) + 1;
        
         
        var sum = parseFloat($('.pts[name="' + priThird + '"]').val()) + parseFloat($(this).val());
    
         
        $('.pts[name="' + nextValue + '"]').val(sum);
        $('#text').val($(this).val());
        $("#send").submit();
         
    });
// Sum up score values ::: END
	
	$( "#sendform" ).submit(function(e) {
		if($('#text').val() != "") {
			$.post("send.php", {text: $('#text').val()});
			$('#text').val("");
		}
		e.preventDefault();
	});
	
	$("#msg").scroll(function() {
		if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
			bottom = true;
			//console.log("bottom");
		}
		else {
			bottom = false;
			//console.log("not bottom");
		}
	});
	
	$("#clickClear").click(function(e) {
		$.post("clear.php");
		$("#msg").text("Cleared scores");
	});
});

function listChat() 
{
	$.get("list.php", function (data) {
		$("#msg").append(data);	
	});
	
}

function listOnline()
{
	$("#online").load("online.php");
	//console.log("Updated online");
}
	
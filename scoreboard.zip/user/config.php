<?php
/*

	Database config settings:

*/
$database = array(
	"host" 		=> 	"localhost",
	"username" 	=> 	"root",
	"password" 	=> 	"",
	
	//only edit if you changed the actual database name
	"database" 	=> 	"test_sample"
);